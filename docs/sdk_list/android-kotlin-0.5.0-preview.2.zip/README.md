# Pine Billing SDK — Android Integration Guide

**Audience:** Android billing-app developers integrating the Pine Billing SDK
in a Kotlin or Java app running on a Pinelabs PoS terminal (or any Android
device with the MasterApp companion installed).

**SDK version:** `0.5.0-preview.2` (preview — compiles + 180 unit tests
pass; not yet validated against a real Pinelabs terminal at-the-counter).

**Distribution:** A single `.aar` file. No Maven Central / Google Maven
publication yet — drop the AAR into your project's `libs/` folder.

---

## 1. What's in the handoff

```
android-handoff/
├── pine-billing-sdk-0.5.0-preview.2.aar     2.1 MB; bundles arm64-v8a + armeabi-v7a
└── THIRD_PARTY_NOTICES.md                    License attribution (ship with your app)
```

The AAR contains:

| Component                                  | Path inside AAR                                      |
|--------------------------------------------|------------------------------------------------------|
| Kotlin façade + UniFFI bindings            | `classes.jar`                                        |
| Native library — 64-bit ARM                | `jni/arm64-v8a/libuniffi_pine_billing.so`             |
| Native library — 32-bit ARM                | `jni/armeabi-v7a/libuniffi_pine_billing.so`           |
| ProGuard/R8 keep rules                     | `proguard.txt` (auto-applied via `consumerProguardFiles`) |
| Manifest                                   | `AndroidManifest.xml` (namespace `com.pinelabs.billing.sdk`) |

---

## 2. System requirements

- **Android Gradle Plugin** 8.0+ (tested with AGP 8.6.1).
- **Kotlin** 1.9+ (tested with 2.0.20).
- **JDK 17+** for Gradle (your app code can target older).
- **`minSdk 21`** or higher.
- **`compileSdk 34`** recommended.
- **JVM target 17** for Kotlin compilation (`jvmTarget = "17"`).
- Target device: 64-bit ARM (Pinelabs terminals) or 32-bit ARM (legacy).
  No x86 / x86_64 ABIs in the v1 AAR.

---

## 3. Add the SDK to your app

### 3.1 Drop the AAR into `libs/`

```
your-app/
└── app/
    ├── build.gradle.kts
    └── libs/
        └── pine-billing-sdk-0.5.0-preview.2.aar
```

### 3.2 Wire `app/build.gradle.kts`

```kotlin
android {
    compileSdk = 34
    defaultConfig {
        minSdk = 21
        // Limit ABIs to what the SDK ships — keeps APK size sane.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(files("libs/pine-billing-sdk-0.5.0-preview.2.aar"))

    // The SDK's Kotlin façade pulls in JNA via the AAR's bundled
    // native lib (no extra gradle dependency required for AAR-based
    // UniFFI loading on Android — System.loadLibrary handles it).

    // Kotlin coroutines (recommended for off-main-thread dispatch):
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
```

> #### Note on JNA
>
> Unlike the **desktop JVM JAR**, the Android AAR does **not** require
> a separate `net.java.dev.jna` dependency. UniFFI on Android binds
> via `System.loadLibrary("uniffi_pine_billing")`, and the AAR
> packages the `.so` files under `jni/<abi>/` so Android's native-lib
> loader picks them up automatically.

### 3.3 Permissions in `AndroidManifest.xml`

The SDK itself requests **no permissions**. Permissions you may need
depending on transport / use case:

```xml
<!-- For the Cloud transport (HTTPS to Pinelabs ISM): -->
<uses-permission android:name="android.permission.INTERNET" />

<!-- For PADController transports if your terminal uses Bluetooth: -->
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
<uses-permission android:name="android.permission.BLUETOOTH_SCAN" />

<!-- Foreground service — REQUIRED if you run transactions while
     the user has navigated away from your activity (recommended): -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```

The **AppToApp transport** binds to the Pinelabs MasterApp service via
explicit `Intent` — no extra permission needed, but the MasterApp must
be installed on the device.

---

## 4. Construct the SDK

### 4.1 Kotlin

```kotlin
import com.pinelabs.billing.sdk.PineBillingSdk
import com.pinelabs.billing.sdk.AndroidSystemBridge
import uniffi.pine_billing.*

fun createSdk(applicationContext: Context): PineBillingSdk {
    val config = SdkConfig(
        defaultTimeoutMs = 60_000u,
        logLevel         = LogLevel.INFO,

        // Pick ONE transport at construction (or set to null and call
        // sdk.setTransport(...) later).
        transport        = TransportType.APP_TO_APP,

        // AppToApp identity — required when transport = AppToApp.
        appToApp = AppToAppConfig(
            userId  = "your-user-id",
            version = "1.0",                      // production MUST be "1.0"
        ),
        applicationId = "<pinelabs-issued-app-id>",

        // Cloud config — required if you intend to setTransport(CLOUD).
        cloud = CloudConfig(
            type             = CloudType.ISM,
            baseUrl          = "https://your-pinelabs-ism-endpoint.example.com",
            connectTimeoutMs = 5_000u,
            readTimeoutMs    = 245_000u,
        ),

        // PADController config — for Bluetooth / USB / Serial transports
        // routed via the local PADController daemon on the terminal.
        padController = PadControllerConfig(
            host              = "127.0.0.1",
            port              = 8082u,
            connectTimeoutMs  = 5_000u,
            socketTimeoutMs   = 245_000u,         // floor: 245_000 ms
        ),
    )

    return PineBillingSdk(
        context        = applicationContext,
        config         = config,
        platformBridge = AndroidSystemBridge(applicationContext),  // for restart() on PADController
    )
}
```

### 4.2 Java

The Kotlin façade is `@JvmOverloads`-friendly, so Java callers can
construct it directly — but the underlying UniFFI types (`SdkConfig`,
`CloudConfig`, etc.) use Kotlin `UInt`/`ULong` which Java cannot reach
from a primary constructor.

**Recommended:** add a tiny Kotlin helper class to your project that
exposes Java-friendly factory methods (same pattern as the desktop JVM
guide). After that, every other SDK call is fully Java-compatible.

```java
import com.pinelabs.billing.sdk.PineBillingSdk;
import com.yourcompany.billing.SdkConfigs;     // your tiny Kotlin helper

PineBillingSdk sdk = new PineBillingSdk(
    getApplicationContext(),
    SdkConfigs.appToApp("user-id", "1.0", "<app-id>"),
    null);                                       // no platform bridge
```

---

## 5. Run a transaction

### 5.1 AppToApp (Pinelabs MasterApp on a terminal)

```kotlin
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import uniffi.pine_billing.*

class CheckoutViewModel(
    private val sdk: PineBillingSdk,
    // ...
) : ViewModel() {

    fun chargeCustomer(amountPaise: ULong, billingRefNo: String) {
        viewModelScope.launch(Dispatchers.IO) {       // ← MUST NOT run on main thread
            val request = TransactionRequest(
                amount             = amountPaise,
                currency           = "INR",
                billingRefNo       = billingRefNo,
                invoiceNo          = null,            // optional on AppToApp
                transactionType    = TransactionType.SALE,
                originalEventId    = null,
                referenceId        = null,
                metadata           = null,
                merchantId         = null,            // not needed on AppToApp (terminal-derived)
                terminalId         = null,
                allowedPaymentModes = null,
                transportOptions   = null,            // AppToApp: extras optional, see §6
            )

            try {
                sdk.doTransaction(request, object : TransactionListener {
                    override fun onStarted(eventId: String) {
                        // Persist eventId — required for crash recovery.
                        viewModelScope.launch(Dispatchers.Main) { ui.markChargeStarted(eventId) }
                    }
                    override fun onSuccess(result: TransactionResult) {
                        viewModelScope.launch(Dispatchers.Main) { ui.markCharged(result) }
                    }
                    override fun onFailure(error: SdkException) {
                        viewModelScope.launch(Dispatchers.Main) { ui.markFailed(error) }
                    }
                })
            } catch (e: SdkException.InvalidInput) {
                // Synchronous validation failure — no callback fires.
                viewModelScope.launch(Dispatchers.Main) { ui.showError(e.message) }
            } catch (e: SdkException.OperationInProgress) {
                viewModelScope.launch(Dispatchers.Main) { ui.showError("Already running tx ${e.activeEventId}") }
            }
        }
    }
}
```

### 5.2 Cloud (ISM REST)

Identical pattern — but `transportOptions` is **required** on Cloud:

```kotlin
val request = TransactionRequest(
    amount = 12_500u,
    currency = "INR",
    billingRefNo = "INV-2026-001",
    invoiceNo = "2026-001",
    transactionType = TransactionType.SALE,
    // ... other fields ...
    transportOptions = TransportOptions.Cloud(CloudTransactionOptions(
        merchantId           = "M12345",
        securityToken        = "<pinelabs-issued-token>",
        identity             = CloudIdentity.Imei("STORE-1-POS-1", "<imei>"),
        transactionNumber    = "TXN-2026-001",   // idempotency key
        sequenceNumber       = "1",
        allowedPaymentMode   = "10",              // opaque code; confirm with Pinelabs
        totalInvoiceAmount   = "12500",
        txnType              = 1,
        originalPlutusTransactionReferenceId = null,
        autoCancelDurationMinutes = 5u,
    )),
)
```

> **Cloud `doTransaction` resolution semantics:** the listener
> `onSuccess` fires with `status = TransactionStatus.PENDING` and
> `transactionId = PlutusTransactionReferenceID`. Drive settlement
> via `sdk.checkStatus(transactionId, CheckStatusOptions.Cloud(...))`.

---

## 6. Threading & lifecycle rules (Android)

**The SDK enforces these — violations fail loudly:**

1. **Never call any blocking SDK method from the main thread.** The
   façade throws `IllegalStateException` if you do. Use
   `Dispatchers.IO`, an `ExecutorService`, or `WorkManager`.

2. **Listener callbacks fire on an SDK-internal thread.** Marshal back
   to `Dispatchers.Main` before touching UI.

3. **One operation at a time per `PineBillingSdk` instance.**
   Concurrent calls raise `SdkException.OperationInProgress(activeEventId)`.
   Disable the trigger control on `onStarted` and re-enable on
   `onSuccess`/`onFailure`.

4. **Construct once per process, reuse.** The instance holds
   Rust-side state. Don't instantiate per-Activity.

5. **The SDK writes no durable state to disk.** If your process is
   killed mid-transaction (Android low-memory, crash), persist the
   `eventId` yourself at `onStarted` and call `checkStatus` on the
   next launch. Strongly recommended: run transactions in a
   foreground service so the OS doesn't kill you mid-PIN-entry.

6. **Do `sdk.close()` (it implements `AutoCloseable`)** when you're
   genuinely shutting down, e.g. in `Application.onTerminate()` or
   when a long-lived component goes away. Not necessary per-Activity.

---

## 7. Public API — Android-specific bits

### 7.1 `PineBillingSdk` constructor

```kotlin
@Throws(SdkException::class)
@JvmOverloads
public constructor(
    context: Context,
    config: SdkConfig,
    platformBridge: PlatformBridge? = null,
)
```

- `context` — application context is held internally; passing an
  Activity is safe (we extract the application context).
- `config` — same `SdkConfig` shape as desktop JVM. The Android
  façade automatically wires the AppToApp bridge from
  `config.appToApp` + `config.applicationId`; you don't pass an
  AppToApp bridge yourself.
- `platformBridge` — pass an `AndroidSystemBridge(context)` if you
  intend to call `sdk.restart()` on the PADController transport;
  pass `null` for AppToApp / Cloud-only deployments.

### 7.2 `AndroidSystemBridge`

Pre-built `PlatformBridge` implementation. Restarts the PADController
service via an Android `Intent`. Two delivery modes:

```kotlin
public class AndroidSystemBridge(
    context: Context,
    deliveryMode: DeliveryMode = DeliveryMode.SERVICE,
) : PlatformBridge {
    public enum class DeliveryMode { SERVICE, BROADCAST }
}
```

Some MasterApp builds expect a `startService` intent; others expect a
broadcast. Default is `SERVICE`; switch to `BROADCAST` if your
MasterApp variant requires it.

### 7.3 Transports available on Android

| Transport                                | Available on Android |
|------------------------------------------|----------------------|
| `APP_TO_APP` (Pinelabs MasterApp IPC)    | ✅ Primary path on Pinelabs terminals. |
| `CLOUD` (Pinelabs ISM REST)              | ✅                    |
| `BLUETOOTH` / `USB` / `SERIAL` (PADController) | ✅ Routes via local PADController daemon. |
| `TCP` direct                             | ❌ Reserved (v1 placeholder). |

### 7.4 ProGuard / R8

The AAR ships its own `consumer-rules.pro` keeping all `uniffi.*`
classes (UniFFI's JNI bindings rely on reflection). Your app's R8
config does not need any extra rules — they're applied automatically
when the AAR is consumed.

---

## 8. Error model

Same `SdkException` hierarchy as desktop JVM. On Android, common
variants you'll handle:

| Variant                          | Typical Android cause |
|----------------------------------|-----------------------|
| `InvalidInput`                   | Bad `TransactionRequest`. |
| `TransportUnavailable`           | MasterApp not installed (AppToApp), no internet (Cloud), PADController daemon down. |
| `Timeout`                        | Cardholder didn't enter PIN in time, terminal frozen. |
| `TransactionFailed`              | Acquirer declined; check `terminalResponseCode`. |
| `OperationInProgress`            | Another tx is in flight. |
| `Cancelled`                      | Caller cancelled and tx didn't commit. |
| `NotSupported`                   | Capability not implemented on the active transport. |
| `ConnectionTimeout` / `ReadTimeout` / `Network` / `NonSuccessHttp` | Cloud-only network errors. |

**Catch the parent `SdkException`** for a generic error path, then
branch on subtypes for specific UI / retry logic.

---

## 9. Logging

- **Never log card data, PINs, CVVs, full PANs, keys, or tokens.**
- `maskedPan` (last-4 only) is safe at `Log.DEBUG`.
- `eventId`, `responseCode`, `responseMessage`, `acquirer`,
  `transactionId` are safe at `Log.INFO`.
- Set verbosity via `SdkConfig.logLevel`. Default `INFO`.
- The SDK does **not** phone home — no telemetry / analytics /
  crash reporters. The only outbound traffic is the configured
  transport.

---

## 10. Testing

### 10.1 Unit tests (Robolectric / JVM)

The SDK's own test suite uses Robolectric (`isReturnDefaultValues = true`).
For your own unit tests:

- The native `.so` does **not** load on the JVM, so any test that
  reaches a real SDK call must run on a real device / emulator.
- For pure-logic tests of code that uses the SDK, use a `mockk`/Mockito
  mock of `PineBillingSdk` — the public class has no `final` issues
  because we use `open` where needed.

### 10.2 Instrumentation tests

Run on a real Pinelabs terminal or an emulator with the MasterApp
installed (or use Cloud). The SDK does not provide its own MasterApp
mock.

---

## 11. Troubleshooting

### `UnsatisfiedLinkError: Couldn't load uniffi_pine_billing`

Most often: a 64-bit-only `.so` on a 32-bit-only device, or vice
versa. Check that your `abiFilters` includes the AAR's two ABIs:

```kotlin
ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
```

Also verify the AAR is intact:

```bash
unzip -l libs/pine-billing-sdk-0.5.0-preview.2.aar | grep \\.so$
# → jni/arm64-v8a/libuniffi_pine_billing.so
# → jni/armeabi-v7a/libuniffi_pine_billing.so
```

### `IllegalStateException: doTransaction() must not be called from the Android main thread`

You called the SDK from the UI thread. Wrap in
`viewModelScope.launch(Dispatchers.IO)` or an `ExecutorService`.

### `TransportUnavailable: MasterApp Messenger service not bound`

The Pinelabs MasterApp is not installed or not running on the
terminal. Reinstall MasterApp; verify with:

```bash
adb shell pm list packages | grep masterapp
```

### `OperationInProgress(activeEventId)`

Another transaction is still in flight on this SDK instance. Either
wait for the listener callback or call
`sdk.cancel(activeEventId, null)` to abort.

### App is killed during transaction (low memory)

Run transactions in a **foreground service**, not a regular service or
a viewmodelscope. Persist `eventId` at `onStarted` so you can
`checkStatus(...)` on the next launch.

### R8 / ProGuard stripping UniFFI classes

The AAR's `consumer-rules.pro` should prevent this. If you've
overridden it, add:

```proguard
-keep class uniffi.pine_billing.** { *; }
-keep class com.pinelabs.billing.sdk.** { *; }
-keepclassmembers class * implements uniffi.pine_billing.UniffiCallbackInterface { *; }
```

---

## 12. Preview-build caveats

This is a **preview build**:

- ✅ Compiles + 180 unit tests pass.
- ✅ AAR built with NDK r28.2 against AGP 8.6.1.
- ✅ Robolectric tests pass on JVM.
- ⚠️ **Not yet validated on a real Pinelabs terminal.**
- ⚠️ **Not yet validated against a real Pinelabs ISM cloud endpoint.**
- ⚠️ **No real MasterApp IPC round-trip exercised.**

For QA / smoke / integration testing only — do **not** ship to
production. Production builds will be `0.5.0` GA after
real-hardware smoke pass.

---

## 13. Support

When raising an issue, please include:

1. SDK version (`0.5.0-preview.2`).
2. Android version (`adb shell getprop ro.build.version.release`).
3. Device model + ABI (`adb shell getprop ro.product.cpu.abilist`).
4. MasterApp version (if AppToApp).
5. `eventId` and the `SdkException` subtype name.
6. **Never share** card data, PINs, CVVs, full PANs, security tokens,
   or merchant credentials in support tickets.

---

## 14. License

The SDK is proprietary. See `THIRD_PARTY_NOTICES.md` for the
licenses of the transitively-included open-source crates
(Apache-2.0, MIT, BSD-2-Clause, BSD-3-Clause, ISC, MPL-2.0,
Unicode-DFS-2016, Zlib, CC0-1.0, OpenSSL).
